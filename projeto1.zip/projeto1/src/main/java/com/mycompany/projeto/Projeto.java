/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 */

package com.mycompany.projeto;

/**
 *
 * @author rodri
 */
public class Projeto {

    public static void main(String[] args) {
        System.out.println("Hello World!");
    }
}
